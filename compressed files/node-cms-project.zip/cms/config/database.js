module.exports = {

    mongoDbUrl: 'mongodb://localhost:27017/cms'

};